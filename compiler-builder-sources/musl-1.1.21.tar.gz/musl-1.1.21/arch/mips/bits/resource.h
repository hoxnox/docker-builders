#define RLIMIT_NOFILE  5
#define RLIMIT_AS      6
#define RLIMIT_RSS     7
#define RLIMIT_NPROC   8
#define RLIMIT_MEMLOCK 9
