#define APPLY_DOMBASE union_set
#define APPLY_DOM isl_union_set

#include <isl_multi_apply_templ.c>

#undef APPLY_DOMBASE
#undef APPLY_DOM
