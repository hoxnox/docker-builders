#ifndef ISL_HASH_PRIVATE
#define ISL_HASH_PRIVATE

#include <isl/hash.h>

extern struct isl_hash_table_entry *isl_hash_table_entry_none;

#endif
