for (int c0 = 0; c0 <= 64; c0 += 1)
  sync();
