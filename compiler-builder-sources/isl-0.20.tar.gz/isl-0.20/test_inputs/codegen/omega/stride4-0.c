for (int c0 = 18; c0 <= 98; c0 += 5)
  s0(c0);
