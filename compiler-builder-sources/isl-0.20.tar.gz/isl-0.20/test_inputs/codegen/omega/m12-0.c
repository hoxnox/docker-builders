for (int c1 = 1; c1 <= n; c1 += 1)
  for (int c2 = 1; c2 <= m; c2 += 1)
    s0(1, c1, c2, 0);
