for (int c0 = 0; c0 <= 99; c0 += 1) {
  if (c0 >= 4 && c0 <= 6) {
    for (int c1 = 0; c1 <= 99; c1 += 1)
      A(c0, c1);
  } else {
    for (int c1 = 0; c1 <= 99; c1 += 1)
      A(c0, c1);
  }
}
