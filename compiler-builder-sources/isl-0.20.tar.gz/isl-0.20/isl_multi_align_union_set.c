#define ALIGN_DOMBASE union_set
#define ALIGN_DOM isl_union_set

#include <isl_multi_align_templ.c>

#undef ALIGN_DOMBASE
#undef ALIGN_DOM
